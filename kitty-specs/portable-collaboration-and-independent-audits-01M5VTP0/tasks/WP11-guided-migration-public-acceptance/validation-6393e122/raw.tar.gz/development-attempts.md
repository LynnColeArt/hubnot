# Pre-final development attempts

Behavior-first tests initially failed to compile because the CLI/wizard symbols did not yet exist; implementation then made them pass. These early outputs remain in the chat tool history; no separate complete raw external log was recorded.

An expanded development focused run refused GitLab quick-action recreation correctly, but its assertion expected the word "quick"; the actual contractual message was "GitLab slash-command lines are refused". The assertion was changed to that concrete message and the focused suite passed. This was an assertion wording correction, not a deleted refusal/effect assertion.

Commit e45e6602 passed development focused checks but root preflight found that an authenticated API mode could fall back to anonymous writes when the transient token was absent. e45 is superseded. Commit 6393e122 adds the generic shared CLI apply guard and the compiled anonymously-writable-fixture regression. All final gates are source-bound to 6393e122. The root's retained positive/negative control independently proves this assertion is nonvacuous.

No failed full-suite gate was retried or discarded: the only authorized full race invocation passed. Project test defaults, assertions, filters and CI definitions were not weakened.
