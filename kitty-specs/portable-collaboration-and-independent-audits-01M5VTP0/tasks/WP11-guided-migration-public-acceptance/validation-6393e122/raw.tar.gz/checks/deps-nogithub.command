go list -tags 'nogithub' -deps .
