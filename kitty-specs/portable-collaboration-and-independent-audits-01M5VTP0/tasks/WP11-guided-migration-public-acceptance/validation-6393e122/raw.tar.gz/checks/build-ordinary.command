go build -tags '' -o <external-binaries>/hn-ordinary .
