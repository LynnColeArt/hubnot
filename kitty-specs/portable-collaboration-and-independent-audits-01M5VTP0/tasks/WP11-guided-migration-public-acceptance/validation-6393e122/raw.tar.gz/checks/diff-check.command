git diff --check 
