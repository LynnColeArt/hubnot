bash -c test\ -z\ \"\$\(gofmt\ -l\ migration_commands.go\ migration_commands_test.go\ migration_wizard.go\ migration_wizard_test.go\ migration_acceptance_test.go\)\" 
