go build -tags 'noforge' -o <external-binaries>/hn-noforge .
