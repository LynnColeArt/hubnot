go list -tags '' -deps .
