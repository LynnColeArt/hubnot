go build -tags 'nogithub' -o <external-binaries>/hn-nogithub .
