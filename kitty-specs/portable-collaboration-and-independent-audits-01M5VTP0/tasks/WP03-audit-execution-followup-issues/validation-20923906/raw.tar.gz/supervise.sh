#!/usr/bin/env bash
set -u
validation=/tmp/hn-wp03-validation-20923906
workspace=/home/lynn/projects/nichthub/.worktrees/portable-collaboration-and-independent-audits-01M5VTP0-lane-b
expected=20923906ba24c939309540626d525a75729fbabe
cd "$workspace" || exit 90
head_before=$(git rev-parse HEAD)
started=$(date -u +%FT%TZ)
printf '{"pid":%s,"source":"%s","started":"%s","state":"running"}\n' "$$" "$head_before" "$started" > "$validation/running.json.tmp"
mv "$validation/running.json.tmp" "$validation/running.json"
if test "$head_before" != "$expected"; then exit 91; fi
go version > "$validation/toolchain.log" 2>&1
git --version >> "$validation/toolchain.log" 2>&1
go test -race ./... > "$validation/race.log" 2>&1
race_status=$?
go vet ./... > "$validation/vet.log" 2>&1
vet_status=$?
go build ./... > "$validation/build.log" 2>&1
build_status=$?
go build -tags nogithub -o "$validation/hn-nogithub" . > "$validation/nogithub.log" 2>&1
native_status=$?
if test "$native_status" -eq 0; then "$validation/hn-nogithub" audit help >> "$validation/nogithub.log" 2>&1; native_status=$?; fi
gofmt -l audit_commands.go audit_commands_test.go audit_execution.go audit_execution_test.go audit_followup.go audit_followup_test.go > "$validation/gofmt.log" 2>&1
format_status=$?
if test -s "$validation/gofmt.log"; then format_status=1; fi
git diff --check > "$validation/diff-check.log" 2>&1
diff_status=$?
head_after=$(git rev-parse HEAD)
git status --porcelain > "$validation/git-status.log"
ended=$(date -u +%FT%TZ)
exit_status=0
for gate in "$race_status" "$vet_status" "$build_status" "$native_status" "$format_status" "$diff_status"; do if test "$gate" -ne 0; then exit_status=1; fi; done
if test "$head_after" != "$expected" || test -s "$validation/git-status.log"; then exit_status=1; fi
printf '{"pid":%s,"source":"%s","source_after":"%s","started":"%s","ended":"%s","race":%s,"vet":%s,"build":%s,"nogithub_build_and_help":%s,"format":%s,"diff_check":%s,"exit":%s,"adapter_free":"not available in this dependency lane"}\n' "$$" "$head_before" "$head_after" "$started" "$ended" "$race_status" "$vet_status" "$build_status" "$native_status" "$format_status" "$diff_status" "$exit_status" > "$validation/exit.json.tmp"
mv "$validation/exit.json.tmp" "$validation/exit.json"
exit "$exit_status"
