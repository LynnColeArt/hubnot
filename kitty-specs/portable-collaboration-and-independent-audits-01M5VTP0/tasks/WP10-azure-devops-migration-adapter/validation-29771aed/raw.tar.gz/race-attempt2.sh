#!/usr/bin/env bash
set -u
proof=/tmp/hubnot-wp10-complete-tDGpvg
expected=29771aed34e68503c6a4c3f660cbb56f2a335ab0
git rev-parse HEAD > "$proof/race-attempt2-head.txt"
if [ "$(git rev-parse HEAD)" != "$expected" ]; then exit 90; fi
sha256sum -c "$proof/source-sha256.txt" > "$proof/race-attempt2-source-check-before.log" 2>&1 || exit 91
printf '%s\n' 'go test -race -timeout 20m ./...' > "$proof/race-attempt2-command.txt"
printf '%s START race-attempt2 (coordinator-serialized same-head unfiltered retry)\n' "$(date -u +%FT%TZ)" >> "$proof/status.txt"
date -u +%FT%TZ > "$proof/race-attempt2-start.txt"
go test -race -timeout 20m ./... > "$proof/race-attempt2.log" 2>&1
wp10_result=$?
date -u +%FT%TZ > "$proof/race-attempt2-end.txt"
printf '%s\n' "$wp10_result" > "$proof/race-attempt2.exit"
printf '%s EXIT race-attempt2 %s\n' "$(date -u +%FT%TZ)" "$wp10_result" >> "$proof/status.txt"
if [ "$wp10_result" -eq 0 ]; then
 if [ "$(git rev-parse HEAD)" != "$expected" ]; then exit 92; fi
 sha256sum -c "$proof/source-sha256.txt" > "$proof/race-attempt2-source-check-after.log" 2>&1 || exit 93
 if [ "$(cat "$proof/post-race.exit")" != 0 ]; then exit 94; fi
 git status --porcelain=v1 > "$proof/final-status.txt"
 if [ -s "$proof/final-status.txt" ]; then exit 95; fi
 printf '0\n' > "$proof/gate.exit"
 printf '%s PASS fixed-head validation after serialized full-race retry; all distinct checks passed\n' "$(date -u +%FT%TZ)" >> "$proof/status.txt"
fi
exit "$wp10_result"
