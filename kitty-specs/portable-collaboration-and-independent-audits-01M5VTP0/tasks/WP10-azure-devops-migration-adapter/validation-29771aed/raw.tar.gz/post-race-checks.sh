#!/usr/bin/env bash
set -u
proof=/tmp/hubnot-wp10-complete-tDGpvg
expected=$(git rev-parse HEAD)
run() {
 task_name=$1
 shift
 printf '%s START %s\n' "$(date -u +%FT%TZ)" "$task_name" >> "$proof/status.txt"
 "$@" > "$proof/$task_name.log" 2>&1
 result=$?
 printf '%s EXIT %s %s\n' "$(date -u +%FT%TZ)" "$task_name" "$result" >> "$proof/status.txt"
 if [ "$result" -ne 0 ]; then cat "$proof/$task_name.log"; exit "$result"; fi
 if [ "$(git rev-parse HEAD)" != "$expected" ]; then printf 'Source head changed\n'; exit 90; fi
 if [ -f "$proof/stop-between-commands" ]; then printf 'Stopped between completed commands; no checks skipped as passes\n'; exit 97; fi
}
native_case() {
 variant=$1
 binary=$2
 repo="$proof/native-$variant"
 task_home="$proof/home-$variant"
 tool_bin="$proof/git-only-bin"
 mkdir -p "$repo" "$task_home" "$tool_bin"
 if [ ! -e "$tool_bin/git" ]; then ln -s "$(command -v git)" "$tool_bin/git"; fi
 git -c core.hooksPath=/dev/null init --quiet "$repo" || return
 git -C "$repo" config user.name 'WP10 fixture' || return
 git -C "$repo" config user.email 'wp10@example.invalid' || return
 git -C "$repo" -c commit.gpgsign=false -c core.hooksPath=/dev/null commit --allow-empty --quiet -m fixture || return
 (
  cd "$repo" || exit
  env -i PATH="$tool_bin" HOME="$task_home" GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null "$binary" init --name 'Offline Azure fixture' || exit
  env -i PATH="$tool_bin" HOME="$task_home" GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null "$binary" issue open --json --body 'offline-body' 'offline-title' > "$proof/$variant-issue-open.json" || exit
  env -i PATH="$tool_bin" HOME="$task_home" GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null "$binary" issue list --json > "$proof/$variant-issue-list.json" || exit
  env -i PATH="$tool_bin" HOME="$task_home" GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null "$binary" gh issue list > "$proof/$variant-gh-list.txt" || exit
 ) || return
 rg -q 'offline-title' "$proof/$variant-issue-list.json" || return
 rg -q 'offline-title' "$proof/$variant-gh-list.txt" || return
 printf 'PASS offline native issue create/list and gh facade with Git-only PATH, isolated HOME, empty credentials\n'
}
# Continue distinct checks after recorded full-race failure; no full test is claimed here.
run vet go vet ./...
run build go build ./...
run nogithub-focused go test -race -tags nogithub ./... -run '^(TestAzure|TestExplicitVersions|TestRedirectAndForeign|TestSharedWire|TestWIQL|TestCommentsContinuation|TestWorkItemWrite|TestPlanDestinationScope|TestMigration|TestAuditPublicExplicitExecutionFollowUpAndReplication)' -count=1
run noforge-focused go test -race -tags noforge ./... -run '^(TestPlanDestinationScope|TestMigration|TestAuditPublicExplicitExecutionFollowUpAndReplication|TestIssueCommandsReplayLifecycle)' -count=1
run ordinary-build go build -o "$proof/hn" .
run nogithub-build go build -tags nogithub -o "$proof/hn-nogithub" .
run noforge-build go build -tags noforge -o "$proof/hn-noforge" .
run modules go list -m all
run ordinary-deps go list -deps -test ./...
run nogithub-deps go list -tags nogithub -deps -test ./...
run noforge-deps go list -tags noforge -deps -test ./...
run noforge-symbols go tool nm "$proof/hn-noforge"
run noforge-buildinfo go version -m "$proof/hn-noforge"
run ordinary-legacy "$proof/hn" transfer capabilities --provider azure
run nogithub-legacy "$proof/hn-nogithub" transfer capabilities --provider azure
run noforge-native-help "$proof/hn-noforge" issue --help
run ordinary-native-cli native_case ordinary "$proof/hn"
run nogithub-native-cli native_case nogithub "$proof/hn-nogithub"
run noforge-native-cli native_case noforge "$proof/hn-noforge"
run ordinary-files go list -f '{{join .GoFiles "\n"}}' .
run nogithub-files go list -tags nogithub -f '{{join .GoFiles "\n"}}' .
run noforge-files go list -tags noforge -f '{{join .GoFiles "\n"}}' .
run format bash -c 'git diff --name-only dac3c4abbd4b5aaf40a5c31dd5395d64b8ef1116 HEAD | xargs gofmt -l'
if [ -s "$proof/format.log" ]; then cat "$proof/format.log"; exit 91; fi
run diff-check git diff --check dac3c4abbd4b5aaf40a5c31dd5395d64b8ef1116 HEAD
if ! rg -q 'hubnot/internal/azureapi' "$proof/ordinary-deps.log" || ! rg -q 'hubnot/internal/azureapi' "$proof/nogithub-deps.log"; then printf 'Azure missing from ordinary/nogithub dependencies\n';exit 92; fi
if rg -n 'hubnot/internal/(azureapi|githubapi)' "$proof/noforge-deps.log"; then printf 'Excluded clients remain under noforge\n';exit 93; fi
if rg -n 'hubnot/internal/azureapi\.|main\.\(\*azureMigration\)|main\.newAzureMigration' "$proof/noforge-symbols.log"; then printf 'Excluded Azure symbols remain\n';exit 94; fi
if rg -n 'hubnot/internal/githubapi' "$proof/nogithub-deps.log"; then printf 'GitHub retained in nogithub\n';exit 95; fi
git for-each-ref '--format=%(refname) %(objectname)' refs/tags > "$proof/tags-after.txt"
run tag-check cmp "$proof/tags-before.txt" "$proof/tags-after.txt"
git status --porcelain=v1 > "$proof/final-status.txt"
if [ -s "$proof/final-status.txt" ]; then cat "$proof/final-status.txt";exit 96; fi
printf '%s PASS post-race checks; full race remains failed pending authorized serialized rerun\n' "$(date -u +%FT%TZ)" >> "$proof/status.txt"
