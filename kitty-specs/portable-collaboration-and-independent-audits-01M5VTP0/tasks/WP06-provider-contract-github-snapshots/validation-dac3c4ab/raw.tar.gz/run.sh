#!/usr/bin/env bash
set -u
proof=/tmp/hubnot-wp06-final-validation-l2O7D1
expected=dac3c4abbd4b5aaf40a5c31dd5395d64b8ef1116
run() {
 name=$1
 shift
 printf '%s START %s\n' "$(date -u +%FT%TZ)" "$name" | tee -a "$proof/status.txt"
 "$@" > "$proof/$name.log" 2>&1
 status=$?
 printf '%s EXIT %s %s\n' "$(date -u +%FT%TZ)" "$name" "$status" | tee -a "$proof/status.txt"
 if [ "$status" -ne 0 ]; then cat "$proof/$name.log"; exit "$status"; fi
 if [ "$(git rev-parse HEAD)" != "$expected" ]; then printf 'HEAD changed\n'; exit 90; fi
}
native_case() {
 variant=$1
 binary=$2
 repo="$proof/native-$variant"
 home_dir="$proof/home-$variant"
 tool_bin="$proof/git-only-bin"
 mkdir -p "$repo" "$home_dir" "$tool_bin"
 if [ ! -e "$tool_bin/git" ]; then ln -s "$(command -v git)" "$tool_bin/git"; fi
 git -c core.hooksPath=/dev/null init --quiet "$repo" || return
 git -C "$repo" config user.name 'WP06 fixture' || return
 git -C "$repo" config user.email 'wp06@example.invalid' || return
 git -C "$repo" -c commit.gpgsign=false -c core.hooksPath=/dev/null commit --allow-empty --quiet -m fixture || return
 (
  cd "$repo" || exit
  env -i PATH="$tool_bin" HOME="$home_dir" GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null "$binary" init --name 'Offline fixture' || exit
  env -i PATH="$tool_bin" HOME="$home_dir" GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null "$binary" issue open --json --body 'offline-body' 'offline-title' > "$proof/$variant-issue-open.json" || exit
  env -i PATH="$tool_bin" HOME="$home_dir" GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null "$binary" issue list --json > "$proof/$variant-issue-list.json" || exit
  env -i PATH="$tool_bin" HOME="$home_dir" GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null "$binary" gh issue list > "$proof/$variant-gh-issue-list.txt" || exit
 ) || return
 rg -q 'offline-title' "$proof/$variant-issue-list.json" || return
 rg -q 'offline-title' "$proof/$variant-gh-issue-list.txt" || return
 printf 'PASS native issue creation/list and gh facade with Git-only PATH, empty credentials, isolated HOME\n'
}
git rev-parse HEAD > "$proof/head.txt"
git status --porcelain=v1 > "$proof/initial-status.txt"
git diff --name-only 247a4e1b26295459ae159674c109bcd91aa1a954 HEAD > "$proof/owned-files.txt"
while IFS= read -r path; do sha256sum "$path"; done < "$proof/owned-files.txt" > "$proof/source-sha256.txt"
git for-each-ref '--format=%(refname) %(objectname)' refs/tags > "$proof/tags-before.txt"
run race go test -race ./...
run vet go vet ./...
run build go build ./...
run nogithub-focused go test -race -tags nogithub ./... -run '^(TestMigration|TestIssueCommandsReplayLifecycle|TestWorkflowPublicCLIWithoutProvider|TestAuditPublicExplicitExecutionFollowUpAndReplication)' -count=1
run noforge-focused go test -race -tags noforge ./... -run '^(TestMigration|TestIssueCommandsReplayLifecycle|TestWorkflowPublicCLIWithoutProvider|TestAuditPublicExplicitExecutionFollowUpAndReplication)' -count=1
run nogithub-build go build -tags nogithub -o "$proof/hn-nogithub" .
run noforge-build go build -tags noforge -o "$proof/hn-noforge" .
run ordinary-build go build -o "$proof/hn" .
run dependencies go list -m all
run ordinary-deps go list -deps -test ./...
run nogithub-deps go list -tags nogithub -deps -test ./...
run noforge-deps go list -tags noforge -deps -test ./...
run noforge-symbols go tool nm "$proof/hn-noforge"
run noforge-buildinfo go version -m "$proof/hn-noforge"
run ordinary-help "$proof/hn" github help
run nogithub-help "$proof/hn-nogithub" github help
run noforge-help "$proof/hn-noforge" github help
run noforge-native-help "$proof/hn-noforge" issue --help
run ordinary-native-cli native_case ordinary "$proof/hn"
run nogithub-native-cli native_case nogithub "$proof/hn-nogithub"
run noforge-native-cli native_case noforge "$proof/hn-noforge"
run noforge-files go list -tags noforge -f '{{join .GoFiles "\n"}}' .
run nogithub-files go list -tags nogithub -f '{{join .GoFiles "\n"}}' .
run format bash -c 'git diff --name-only 247a4e1b26295459ae159674c109bcd91aa1a954 HEAD | xargs gofmt -l'
if [ -s "$proof/format.log" ]; then cat "$proof/format.log"; exit 91; fi
run diff-check git diff --check
if rg -n 'hubnot/internal/githubapi' "$proof/nogithub-deps.log" "$proof/noforge-deps.log"; then printf 'excluded client remains in dependencies\n';exit 92; fi
if rg -n 'hubnot/internal/githubapi\.|main\.\(\*githubMigration\)|main\.newGitHubMigration' "$proof/noforge-symbols.log"; then printf 'excluded adapter remains in binary\n';exit 93; fi
git for-each-ref '--format=%(refname) %(objectname)' refs/tags > "$proof/tags-after.txt"
run tag-check cmp "$proof/tags-before.txt" "$proof/tags-after.txt"
git status --porcelain=v1 > "$proof/final-status.txt"
if [ -s "$proof/final-status.txt" ]; then cat "$proof/final-status.txt";exit 94; fi
printf '%s PASS fixed-head validation\n' "$(date -u +%FT%TZ)" | tee -a "$proof/status.txt"
