#!/usr/bin/env bash
set -u
proof=/tmp/hubnot-wp08-validation-VC9IZH
expected=b6677667c666148fc6cbe47d29d02a52b8bf0b5d
if [ "$(git rev-parse HEAD)" != "$expected" ]; then exit 90; fi
sha256sum --check "$proof/source-sha256.txt" > "$proof/before-race-retry-hashes.log" || exit
printf '%s START race-20m (same-head retry after preserved600s package timeout; no source/config/assertion changes)\n' "$(date -u +%FT%TZ)" | tee -a "$proof/status.txt"
go test -race -timeout 20m ./... > "$proof/race-20m.log" 2>&1
result=$?
printf '%s EXIT race-20m %s\n' "$(date -u +%FT%TZ)" "$result" | tee -a "$proof/status.txt"
if [ "$(git rev-parse HEAD)" != "$expected" ]; then exit 90; fi
if [ "$result" -ne 0 ]; then tail -100 "$proof/race-20m.log"; exit "$result"; fi
cat "$proof/race-20m.log"
