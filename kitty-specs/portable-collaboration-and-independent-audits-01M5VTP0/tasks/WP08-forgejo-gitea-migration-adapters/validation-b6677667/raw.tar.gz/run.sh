#!/usr/bin/env bash
set -u
proof=/tmp/hubnot-wp08-validation-VC9IZH
expected=b6677667c666148fc6cbe47d29d02a52b8bf0b5d
base=dac3c4abbd4b5aaf40a5c31dd5395d64b8ef1116
run() {
 name=$1
 shift
 printf '%s START %s\n' "$(date -u +%FT%TZ)" "$name" | tee -a "$proof/status.txt"
 "$@" > "$proof/$name.log" 2>&1
 result=$?
 printf '%s EXIT %s %s\n' "$(date -u +%FT%TZ)" "$name" "$result" | tee -a "$proof/status.txt"
 if [ "$result" -ne 0 ]; then cat "$proof/$name.log"; exit "$result"; fi
 if [ "$(git rev-parse HEAD)" != "$expected" ]; then printf 'HEAD changed\n'; exit 90; fi
}
native_case() {
 variant=$1
 binary=$2
 repo="$proof/native-$variant"
 home_dir="$proof/home-$variant"
 tool_bin="$proof/git-only-bin"
 mkdir -p "$repo" "$home_dir" "$tool_bin" || return
 if [ ! -e "$tool_bin/git" ]; then ln -s "$(command -v git)" "$tool_bin/git" || return; fi
 git -c core.hooksPath=/dev/null init --quiet "$repo" || return
 git -C "$repo" config user.name 'WP08 fixture' || return
 git -C "$repo" config user.email 'wp08@example.invalid' || return
 git -C "$repo" -c commit.gpgsign=false -c core.hooksPath=/dev/null commit --allow-empty --quiet -m fixture || return
 (
  cd "$repo" || exit
  env -i PATH="$tool_bin" HOME="$home_dir" GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null "$binary" init --name 'Offline fixture' || exit
  env -i PATH="$tool_bin" HOME="$home_dir" GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null "$binary" issue open --json --body 'offline-body' 'offline-title' > "$proof/$variant-issue-open.json" || exit
  env -i PATH="$tool_bin" HOME="$home_dir" GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null "$binary" issue list --json > "$proof/$variant-issue-list.json" || exit
  env -i PATH="$tool_bin" HOME="$home_dir" GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null "$binary" gh issue list > "$proof/$variant-gh-issue-list.txt" || exit
 ) || return
 rg -q 'offline-title' "$proof/$variant-issue-list.json" || return
 rg -q 'offline-title' "$proof/$variant-gh-issue-list.txt" || return
 printf 'PASS native issue creation/list and gh facade with Git-only PATH, empty credentials, isolated HOME\n'
}
noforge_refusal() {
 for provider in forgejo gitea; do
  if "$proof/hn-noforge" transfer capabilities --provider "$provider" > "$proof/noforge-$provider-refusal.txt" 2>&1; then return 95; fi
  rg -q 'unavailable' "$proof/noforge-$provider-refusal.txt" || return
 done
}
git rev-parse HEAD > "$proof/head.txt"
git status --porcelain=v1 > "$proof/initial-status.txt"
git diff --name-only "$base" HEAD > "$proof/owned-files.txt"
while IFS= read -r file; do sha256sum "$file"; done < "$proof/owned-files.txt" > "$proof/source-sha256.txt"
git for-each-ref '--format=%(refname) %(objectname)' refs/tags > "$proof/tags-before.txt"
run race go test -race ./...
run vet go vet ./...
run build go build ./...
run nogithub-focused go test -count=1 -race -tags nogithub ./... -run '^(TestForgejo|TestGitea|TestV1Migration|TestMigration|TestIssueCommandsReplayLifecycle|TestWorkflowPublicCLIWithoutProvider|TestAuditPublicExplicitExecutionFollowUpAndReplication|TestProviderCoverage|TestRegistry)'
run noforge-focused go test -count=1 -race -tags noforge ./... -run '^(TestMigration|TestIssueCommandsReplayLifecycle|TestWorkflowPublicCLIWithoutProvider|TestAuditPublicExplicitExecutionFollowUpAndReplication|TestProviderCoverage|TestRegistry)'
run ordinary-build go build -o "$proof/hn" .
run nogithub-build go build -tags nogithub -o "$proof/hn-nogithub" .
run noforge-build go build -tags noforge -o "$proof/hn-noforge" .
run dependencies go list -m all
run ordinary-deps go list -deps -test ./...
run nogithub-deps go list -tags nogithub -deps -test ./...
run noforge-deps go list -tags noforge -deps -test ./...
run noforge-symbols go tool nm "$proof/hn-noforge"
run noforge-buildinfo go version -m "$proof/hn-noforge"
run ordinary-forgejo-capabilities "$proof/hn" transfer capabilities --provider forgejo
run ordinary-gitea-capabilities "$proof/hn" transfer capabilities --provider gitea
run nogithub-forgejo-capabilities "$proof/hn-nogithub" transfer capabilities --provider forgejo
run nogithub-gitea-capabilities "$proof/hn-nogithub" transfer capabilities --provider gitea
run noforge-provider-refusal noforge_refusal
run ordinary-native-cli native_case ordinary "$proof/hn"
run nogithub-native-cli native_case nogithub "$proof/hn-nogithub"
run noforge-native-cli native_case noforge "$proof/hn-noforge"
run noforge-files go list -tags noforge -f '{{join .GoFiles "\n"}}' .
run nogithub-files go list -tags nogithub -f '{{join .GoFiles "\n"}}' .
run format bash -c 'git diff --name-only dac3c4abbd4b5aaf40a5c31dd5395d64b8ef1116 HEAD | xargs gofmt -l'
if [ -s "$proof/format.log" ]; then cat "$proof/format.log"; exit 91; fi
run diff-check git diff --check "$base" HEAD
if rg -n 'hubnot/internal/(githubapi|forgejoapi|giteaapi)' "$proof/noforge-deps.log"; then printf 'excluded client remains in dependencies\n'; exit 92; fi
if rg -n 'hubnot/internal/(githubapi|forgejoapi|giteaapi)\.|main\.\(\*v1(Migration|Forge)\)|main\.new(Forgejo|Gitea)Migration' "$proof/noforge-symbols.log"; then printf 'excluded adapter remains in binary\n'; exit 93; fi
if rg -n '(forge|migration)_(forgejo|gitea)\.go' "$proof/noforge-files.log"; then printf 'excluded adapter file remains compiled\n'; exit 94; fi
for provider in forgejo gitea; do
 rg -q "hubnot/internal/${provider}api" "$proof/ordinary-deps.log" || exit 96
 rg -q "hubnot/internal/${provider}api" "$proof/nogithub-deps.log" || exit 97
done
git for-each-ref '--format=%(refname) %(objectname)' refs/tags > "$proof/tags-after.txt"
run tag-check cmp "$proof/tags-before.txt" "$proof/tags-after.txt"
git status --porcelain=v1 > "$proof/final-status.txt"
if [ -s "$proof/final-status.txt" ]; then cat "$proof/final-status.txt"; exit 98; fi
printf '%s PASS fixed-head validation\n' "$(date -u +%FT%TZ)" | tee -a "$proof/status.txt"
