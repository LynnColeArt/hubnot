#!/usr/bin/env bash
set -u
cd /home/lynn/projects/nichthub/.worktrees/portable-collaboration-and-independent-audits-01M5VTP0-lane-d || exit 99
run_dir=/tmp/hn-wp05-review-transition-ecaffbfc
source_head=ecaffbfc89affc63bf6af7289a55cd3ac403bdff
actual_head=$(git rev-parse HEAD)
if test "$actual_head" != "$source_head"; then exit 98; fi
if test -n "$(git status --short)"; then exit 97; fi
printf '{"source":"%s","pid":%s,"start":"%s","primary_evidence_commit":"4e626abf"}\n' "$source_head" "$$" "$(date -u +%FT%TZ)" > "$run_dir/supervisor.json"
env -u SPEC_KITTY_SYNC_DISABLE -u SPEC_KITTY_SYNC_MINIMAL_IMPORT spec-kitty agent tasks move-task WP05 --to for_review --mission portable-collaboration-and-independent-audits-01M5VTP0 --note 'Ready for independent review at ecaffbfc; complete fixed-source validation preserved in PRIMARY validation-ecaffbfc by 4e626abf.' --json > "$run_dir/move-task.stdout" 2> "$run_dir/move-task.stderr"
result=$?
printf '{"source":"%s","exit":%s,"end":"%s"}\n' "$source_head" "$result" "$(date -u +%FT%TZ)" > "$run_dir/exit.tmp"
mv "$run_dir/exit.tmp" "$run_dir/exit.json"
exit "$result"
