#!/usr/bin/env bash
set -u
cd /home/lynn/projects/nichthub/.worktrees/portable-collaboration-and-independent-audits-01M5VTP0-lane-d || exit 99
run_dir=/tmp/hn-wp05-validation-ecaffbfc
source_head=ecaffbfc
actual_head=$(git rev-parse HEAD)
case "$actual_head" in "$source_head"*) ;; *) exit 98 ;; esac
printf '{"source":"%s","pid":%s,"start":"%s"}\n' "$actual_head" "$$" "$(date -u +%FT%TZ)" > "$run_dir/supervisor.json"
run_check() {
 local name="$1"
 shift
 "$@" > "$run_dir/$name.stdout" 2> "$run_dir/$name.stderr"
 local result=$?
 printf '{"source":"%s","check":"%s","exit":%s,"end":"%s"}\n' "$actual_head" "$name" "$result" "$(date -u +%FT%TZ)" > "$run_dir/$name.exit.tmp"
 mv "$run_dir/$name.exit.tmp" "$run_dir/$name.exit.json"
 return "$result"
}
run_check race go test -json -race ./...
race_result=$?
run_check vet go vet ./...
vet_result=$?
run_check build go build ./...
build_result=$?
run_check nogithub-tests go test -json -tags=nogithub ./... -run '^(TestMigration|TestProjectSnapshot|TestCanonicalWrite|TestPlanLoss|TestProgressRequires|TestReconciliation)'
nogithub_result=$?
run_check nogithub-build go build -tags=nogithub -o "$run_dir/hn-nogithub" .
nogithub_build_result=$?
run_check noforge-tag-compatibility go test -json -tags=noforge ./... -run '^(TestMigration|TestProjectSnapshot|TestCanonicalWrite|TestPlanLoss|TestProgressRequires|TestReconciliation)'
noforge_result=$?
run_check migration-package-deps go list -deps ./internal/migration
run_check noforge-current-deps go list -tags=noforge -deps ./...
run_check diff-check git diff --check HEAD^
run_check format gofmt -l project_snapshot.go internal/migration/plan.go internal/migration/plan_test.go internal/migration/progress.go internal/migration/progress_test.go migration_engine.go migration_engine_test.go migration_journal.go migration_journal_test.go migration_local.go migration_local_test.go migration_native.go migration_native_test.go
format_result=$?
if test -s "$run_dir/format.stdout"; then format_result=1; fi
printf '{"source":"%s","race":%s,"vet":%s,"build":%s,"nogithub_tests":%s,"nogithub_build":%s,"noforge_tag_compatibility":%s,"format":%s,"end":"%s"}\n' "$actual_head" "$race_result" "$vet_result" "$build_result" "$nogithub_result" "$nogithub_build_result" "$noforge_result" "$format_result" "$(date -u +%FT%TZ)" > "$run_dir/final.tmp"
mv "$run_dir/final.tmp" "$run_dir/final.json"
