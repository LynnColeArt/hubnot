#!/bin/bash
set -u
cd /home/lynn/projects/nichthub/.worktrees/portable-collaboration-and-independent-audits-01M5VTP0-lane-h || exit 1
wp09_evidence=/tmp/hn-wp09-final-evidence.0VKmQg
wp09_runtime=$(mktemp -d /tmp/hn-wp09-runtime.XXXXXX)
printf '%s\n' "$wp09_runtime" > "$wp09_evidence/runtime-path.txt"
wp09_files=(internal/bitbucketapi/client.go internal/bitbucketapi/client_test.go internal/bitbucketapi/migration.go internal/bitbucketapi/migration_test.go migration_bitbucket.go migration_bitbucket_test.go)
git rev-parse HEAD > "$wp09_evidence/source-head.txt"
sha256sum "${wp09_files[@]}" > "$wp09_evidence/source-sha256.txt"
git status --porcelain > "$wp09_evidence/source-status.txt"
git diff dac3c4abbd4b5aaf40a5c31dd5395d64b8ef1116 -- "${wp09_files[@]}" > "$wp09_evidence/source.patch"
run() {
 local wp09_label="$1"
 shift
 {
  printf 'COMMAND:'
  printf ' %q' "$@"
  printf '\n'
  date -u '+START %Y-%m-%dT%H:%M:%SZ'
  git rev-parse HEAD
 } > "$wp09_evidence/$wp09_label.command.txt"
 "$@" > "$wp09_evidence/$wp09_label.raw.txt" 2>&1
 local wp09_status=$?
 {
  printf 'EXIT %s\n' "$wp09_status"
  date -u '+END %Y-%m-%dT%H:%M:%SZ'
  git rev-parse HEAD
  sha256sum "${wp09_files[@]}"
 } >> "$wp09_evidence/$wp09_label.command.txt"
 printf '%s %s\n' "$wp09_label" "$wp09_status" | tee -a "$wp09_evidence/statuses.txt"
}
run vet go vet ./...
run build go build ./...
run focused-normal go test . ./internal/bitbucketapi -run 'TestBitbucket|TestCloud|TestOpaque|TestHostile|TestMigrationProvider|TestGitHubMigration|TestForge|TestTransfer' -count=1
run focused-nogithub go test -tags nogithub . ./internal/bitbucketapi -run 'TestBitbucket|TestCloud|TestOpaque|TestHostile|TestMigrationProvider|TestMigrationLocalForeignRecordsOfflineAndArchiveRoundTrip|TestMigrationComposed' -count=1
run focused-noforge go test -tags noforge . ./internal/migration -run 'TestMigration|TestArchive|TestProvider' -count=1
run diff-check git diff --check
run committed-diff-check git diff dac3c4abbd4b5aaf40a5c31dd5395d64b8ef1116 --check
run formatting gofmt -l "${wp09_files[@]}"
run binary-normal go build -o "$wp09_runtime/hn" .
run binary-nogithub go build -tags nogithub -o "$wp09_runtime/hn-nogithub" .
run binary-noforge go build -tags noforge -o "$wp09_runtime/hn-noforge" .
run deps-normal go list -deps .
run deps-nogithub go list -tags nogithub -deps .
run deps-noforge go list -tags noforge -deps .
run files-normal go list -f '{{join .GoFiles "\n"}}' .
run files-nogithub go list -tags nogithub -f '{{join .GoFiles "\n"}}' .
run files-noforge go list -tags noforge -f '{{join .GoFiles "\n"}}' .
run symbols-normal go tool nm "$wp09_runtime/hn"
run symbols-nogithub go tool nm "$wp09_runtime/hn-nogithub"
run symbols-noforge go tool nm "$wp09_runtime/hn-noforge"
