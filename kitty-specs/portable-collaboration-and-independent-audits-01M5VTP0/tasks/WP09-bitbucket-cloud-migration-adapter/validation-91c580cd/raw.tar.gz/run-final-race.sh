#!/bin/bash
set -u
cd /home/lynn/projects/nichthub/.worktrees/portable-collaboration-and-independent-audits-01M5VTP0-lane-h || exit 1
wp09_evidence=/tmp/hn-wp09-final-evidence.0VKmQg
if [ "$(git rev-parse HEAD)" != 91c580cda750a77493e933e086d0b535d4e7c724 ]; then exit 2; fi
sha256sum -c "$wp09_evidence/source-sha256.txt" > "$wp09_evidence/pre-race-source-verification.raw.txt" || exit 2
{
 printf 'COMMAND: go test -race -timeout 20m ./...\n'
 date -u '+START %Y-%m-%dT%H:%M:%SZ'
 git rev-parse HEAD
} > "$wp09_evidence/full-race.command.txt"
go test -race -timeout 20m ./... > "$wp09_evidence/full-race.raw.txt" 2>&1
wp09_status=$?
{
 printf 'EXIT %s\n' "$wp09_status"
 date -u '+END %Y-%m-%dT%H:%M:%SZ'
 git rev-parse HEAD
 sha256sum internal/bitbucketapi/client.go internal/bitbucketapi/client_test.go internal/bitbucketapi/migration.go internal/bitbucketapi/migration_test.go migration_bitbucket.go migration_bitbucket_test.go
} >> "$wp09_evidence/full-race.command.txt"
printf 'full-race %s\n' "$wp09_status" | tee -a "$wp09_evidence/statuses.txt"
exit "$wp09_status"
