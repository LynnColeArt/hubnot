#!/bin/bash
set -u
wp09_evidence=$1
wp09_runtime=$(cat "$wp09_evidence/runtime-path.txt")
wp09_source=/home/lynn/projects/nichthub/.worktrees/portable-collaboration-and-independent-audits-01M5VTP0-lane-h
mkdir -p "$wp09_runtime/git-only"
ln -s /usr/bin/git "$wp09_runtime/git-only/git"
run() {
 local wp09_label="$1"
 shift
 {
  printf 'COMMAND:'; printf ' %q' "$@"; printf '\n'
  date -u '+START %Y-%m-%dT%H:%M:%SZ'
  git -C "$wp09_source" rev-parse HEAD
 } > "$wp09_evidence/$wp09_label.command.txt"
 "$@" > "$wp09_evidence/$wp09_label.raw.txt" 2>&1
 local wp09_status=$?
 {
  printf 'EXIT %s\n' "$wp09_status"
  date -u '+END %Y-%m-%dT%H:%M:%SZ'
  git -C "$wp09_source" rev-parse HEAD
 } >> "$wp09_evidence/$wp09_label.command.txt"
 printf '%s %s\n' "$wp09_label" "$wp09_status" | tee -a "$wp09_evidence/statuses.txt"
}
for wp09_variant in normal nogithub noforge; do
 wp09_fixture="$wp09_runtime/fixture-$wp09_variant"
 mkdir -p "$wp09_fixture/home" "$wp09_fixture/repository"
 wp09_binary="$wp09_runtime/hn"
 if [ "$wp09_variant" != normal ]; then wp09_binary="$wp09_runtime/hn-$wp09_variant"; fi
 wp09_env=(/usr/bin/env -i HOME="$wp09_fixture/home" XDG_CONFIG_HOME="$wp09_fixture/home/config" PATH="$wp09_runtime/git-only" GIT_CONFIG_NOSYSTEM=1 GIT_CONFIG_GLOBAL=/dev/null GIT_TERMINAL_PROMPT=0)
 cd "$wp09_fixture/repository" || exit 1
 run "$wp09_variant-smoke-git-init" "${wp09_env[@]}" /usr/bin/git init -q -b main
 run "$wp09_variant-smoke-git-name" "${wp09_env[@]}" /usr/bin/git config user.name NativeSmoke
 run "$wp09_variant-smoke-git-email" "${wp09_env[@]}" /usr/bin/git config user.email smoke@hn.invalid
 run "$wp09_variant-smoke-git-commit" "${wp09_env[@]}" /usr/bin/git commit --allow-empty -qm base
 run "$wp09_variant-smoke-init" "${wp09_env[@]}" "$wp09_binary" init --name NativeSmoke
 run "$wp09_variant-smoke-issue-open" "${wp09_env[@]}" "$wp09_binary" issue open --body 'Offline native body' --json 'Offline native issue'
 run "$wp09_variant-smoke-issue-list" "${wp09_env[@]}" "$wp09_binary" issue list --json
 run "$wp09_variant-smoke-gh-list" "${wp09_env[@]}" "$wp09_binary" gh issue list
 run "$wp09_variant-smoke-transfer-help" "${wp09_env[@]}" "$wp09_binary" transfer help
 run "$wp09_variant-smoke-github-help" "${wp09_env[@]}" "$wp09_binary" github help
 run "$wp09_variant-smoke-version" "${wp09_env[@]}" "$wp09_binary" version
 done
