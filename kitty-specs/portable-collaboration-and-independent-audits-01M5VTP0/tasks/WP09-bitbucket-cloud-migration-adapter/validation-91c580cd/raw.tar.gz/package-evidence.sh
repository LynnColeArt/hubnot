#!/bin/bash
set -eu
wp09_evidence=/tmp/hn-wp09-final-evidence.0VKmQg
wp09_source=/home/lynn/projects/nichthub/.worktrees/portable-collaboration-and-independent-audits-01M5VTP0-lane-h
wp09_primary=/home/lynn/projects/nichthub/kitty-specs/portable-collaboration-and-independent-audits-01M5VTP0/tasks/WP09-bitbucket-cloud-migration-adapter/validation-91c580cd
cd "$wp09_source"
test "$(git rev-parse HEAD)" = 91c580cda750a77493e933e086d0b535d4e7c724
sha256sum -c "$wp09_evidence/source-sha256.txt"
rg -q '^full-race 0$' "$wp09_evidence/statuses.txt"
if rg -n ' [^0]$' "$wp09_evidence/statuses.txt"; then exit 2; fi
cd "$wp09_evidence"
wp09_candidates=( *.raw.txt *.command.txt source-head.txt source-sha256.txt source-status.txt source.patch statuses.txt research.txt interface-notes.md provenance-limitation.txt extra-proof-commands.txt runtime-path.txt run-gates.sh run-smoke.sh run-final-race.sh verify-variant-proofs.sh validation-summary.md )
wp09_raw_files=()
for wp09_candidate in "${wp09_candidates[@]}"; do
 if [ "$wp09_candidate" != package-verification.raw.txt ]; then wp09_raw_files+=( "$wp09_candidate" ); fi
done
wp09_raw_files+=( package-evidence.sh )
sha256sum "${wp09_raw_files[@]}" > archive-members.sha256
wp09_member_list=$(mktemp /tmp/hn-wp09-raw-members.XXXXXX)
printf '%s\n' "${wp09_raw_files[@]}" archive-members.sha256 > "$wp09_member_list"
tar -czf raw.tar.gz --files-from "$wp09_member_list"
tar -tzf raw.tar.gz > archive-member-list.txt
wp09_verify=$(mktemp -d /tmp/hn-wp09-archive-verification.XXXXXX)
tar -xzf raw.tar.gz -C "$wp09_verify"
(cd "$wp09_verify" && sha256sum -c archive-members.sha256) > archive-verification.log
mkdir -p "$wp09_primary"
wp09_deliverables=( raw.tar.gz archive-members.sha256 archive-member-list.txt archive-verification.log source-head.txt source-sha256.txt statuses.txt validation-summary.md interface-notes.md research.txt provenance-limitation.txt )
cp "${wp09_deliverables[@]}" "$wp09_primary/"
cd "$wp09_primary"
sha256sum "${wp09_deliverables[@]}" > SHA256SUMS
sha256sum -c SHA256SUMS
printf 'Primary evidence: %s\nRetained archive verification: %s\n' "$wp09_primary" "$wp09_verify"
