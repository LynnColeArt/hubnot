#!/bin/bash
set -eu
cd /tmp/hn-wp09-final-evidence.0VKmQg
rg -q '^hubnot/internal/bitbucketapi$' deps-normal.raw.txt
rg -q '^hubnot/internal/bitbucketapi$' deps-nogithub.raw.txt
if rg -q '^hubnot/internal/(bitbucketapi|githubapi)$' deps-noforge.raw.txt; then exit 1; fi
if rg -q '^hubnot/internal/githubapi$' deps-nogithub.raw.txt; then exit 1; fi
rg -q '^migration_bitbucket.go$' files-normal.raw.txt
rg -q '^migration_bitbucket.go$' files-nogithub.raw.txt
if rg -q 'migration_bitbucket.go|migration_github.go' files-noforge.raw.txt; then exit 1; fi
rg -q 'bitbucketapi.NewClient' symbols-normal.raw.txt
rg -q 'bitbucketapi.NewClient' symbols-nogithub.raw.txt
if rg -q 'bitbucketMigration|bitbucketapi|githubapi' symbols-noforge.raw.txt; then exit 1; fi
test ! -s formatting.raw.txt
test ! -s source-status.txt
for wp09_variant in normal nogithub noforge; do
 rg -q 'Offline native issue' "$wp09_variant-smoke-issue-list.raw.txt"
 rg -q 'Offline native issue' "$wp09_variant-smoke-gh-list.raw.txt"
done
printf '%s\n' 'PASS: nogithub keeps Bitbucket, excludes GitHub; noforge strips provider files/dependencies/symbols.'
printf '%s\n' 'PASS: all three isolated Git-only PATH native smokes created and listed a native issue.'
cd /home/lynn/projects/nichthub/.worktrees/portable-collaboration-and-independent-audits-01M5VTP0-lane-h
sha256sum -c /tmp/hn-wp09-final-evidence.0VKmQg/source-sha256.txt
test "$(git rev-parse HEAD)" = 91c580cda750a77493e933e086d0b535d4e7c724
printf '%s\n' 'PASS: HEAD and six source hashes unchanged.'
